import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2ddbdde8 = () => interopDefault(import('../pages/about.vue' /* webpackChunkName: "pages/about" */))
const _653773dd = () => interopDefault(import('../pages/archive.vue' /* webpackChunkName: "pages/archive" */))
const _5b731f5a = () => interopDefault(import('../pages/friend.vue' /* webpackChunkName: "pages/friend" */))
const _173b5bc4 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _42ecf698 = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _9e05fd60 = () => interopDefault(import('../pages/detailed/_id.vue' /* webpackChunkName: "pages/detailed/_id" */))
const _540aca91 = () => interopDefault(import('../pages/follow/_id.vue' /* webpackChunkName: "pages/follow/_id" */))
const _288b38f9 = () => interopDefault(import('../pages/category/_name/_id.vue' /* webpackChunkName: "pages/category/_name/_id" */))
const _4d93b8ad = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _2ddbdde8,
    name: "about"
  }, {
    path: "/archive",
    component: _653773dd,
    name: "archive"
  }, {
    path: "/friend",
    component: _5b731f5a,
    name: "friend"
  }, {
    path: "/login",
    component: _173b5bc4,
    name: "login"
  }, {
    path: "/register",
    component: _42ecf698,
    name: "register"
  }, {
    path: "/detailed/:id?",
    component: _9e05fd60,
    name: "detailed-id"
  }, {
    path: "/follow/:id?",
    component: _540aca91,
    name: "follow-id"
  }, {
    path: "/category/:name?/:id?",
    component: _288b38f9,
    name: "category-name-id"
  }, {
    path: "/",
    component: _4d93b8ad,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
